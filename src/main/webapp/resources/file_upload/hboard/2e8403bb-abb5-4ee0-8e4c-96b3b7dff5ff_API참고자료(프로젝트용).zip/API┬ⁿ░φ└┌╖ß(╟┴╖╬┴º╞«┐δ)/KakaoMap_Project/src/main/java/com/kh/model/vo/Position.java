package com.kh.model.vo;

public class Position {
	
	private String title;
	private String content;
	private double lat; // 위도
	private double lng; // 경도
	
	public Position() { }

	public Position(String title, String content, double lat, double lng) {
		super();
		this.title = title;
		this.content = content;
		this.lat = lat;
		this.lng = lng;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

	@Override
	public String toString() {
		return "Position [title=" + title + ", content=" + content + ", lat=" + lat + ", lng=" + lng + "]";
	}
}
