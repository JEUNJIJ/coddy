package com.kh.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.kh.model.vo.Position;

/**
 * Servlet implementation class AjaxPositionListController
 */
@WebServlet("/list.po")
public class AjaxPositionListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxPositionListController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// DB 로 부터 위치 정보를 다 불러왔다라는 가정 하에
		ArrayList<Position> list = new ArrayList<>();
		
		Position p1 = new Position();
		p1.setTitle("남산서울타워");
		p1.setContent("서울특별시 남산에 있는 송신탑이자 서울을 대표하는 랜드마크로서, 정식 명칭은 남산서울타워이며 보통은 남산타워로 불리는 편이다. N서울타워로 불리는 경우도 많다.");
		p1.setLat(37.5511694);
		p1.setLng(126.9882266);
		
		Position p2 = new Position();
		p2.setTitle("숭례문");
		p2.setContent("600년 동안 한양을 둘러싸고 있었던 조선 서울 한양도성의 남쪽에 위치한 문. 현재도 서울의 중심에 위치하고 있으며, 서울의 상징이나 다름 없는 건축물이다.");
		p2.setLat(37.559984);
		p2.setLng(126.9753071);
		
		Position p3 = new Position();
		p3.setTitle("리움미술관");
		p3.setContent("삼성문화재단에서 만든 사립 미술관.");
		p3.setLat(37.5378932);
		p3.setLng(126.9993937);
		
		Position p4 = new Position();
		p4.setTitle("전쟁기념관");
		p4.setContent("전쟁기념관은 서울특별시 용산구 이태원로 29(용산동1가)에 위치한 국립 박물관이다.");
		p4.setLat(37.5366059);
		p4.setLng(126.9771397);
		
		Position p5 = new Position();
		p5.setTitle("국립중앙박물관");
		p5.setContent("서울특별시 용산구 용산동6가에 위치한 한국의 대표 국립 박물관. 한국의 고미술, 유물을 중심으로 소장하고 있으며, 소장 유물 약 150만여 점, 상설 전시 유물 1만여 점으로 한국 최대의 박물관이면서 세계적으로도 상당한 규모이다.");
		p5.setLat(37.5238506);
		p5.setLng(126.9804702);
		
		Position p6 = new Position();
		p6.setTitle("남대문시장");
		p6.setContent("서울특별시 중구 회현동 숭례문 앞에 위치해 있는 서울 최대의 재래시장. 서울 지하철 4호선 회현역에서 가깝다.");
		p6.setLat(37.5591786);
		p6.setLng(126.9776692);
		
		Position p7 = new Position();
		p7.setTitle("남산한옥마을");
		p7.setContent("서울특별시 중구 필동 퇴계로에 위치해 있는 한옥 마을. 1998년에 공식 개장하였다. 입장료는 무료이며 매주 월요일은 휴관한다.");
		p7.setLat(37.559315);
		p7.setLng(126.994477);
		
		Position p8 = new Position();
		p8.setTitle("덕수궁");
		p8.setContent("조선시대의 궁궐. 현재 서울특별시 중구 세종대로 99 (정동) 서울특별시청 건너편에 위치해 있다.");
		p8.setLat(37.5658049);
		p8.setLng(126.9751461);
		
		Position p9 = new Position();
		p9.setTitle("서울로");
		p9.setContent("서울특별시 중구 만리동1가, 중림동, 봉래동2가, 남대문로5가, 남창동 일대에 걸쳐 있는 공원. 노후한 옛 서울역의 고가차도를 개·보수하여 만들어졌다.");
		p9.setLat(37.5566606);
		p9.setLng(126.9705394);
		
		Position p10 = new Position();
		p10.setTitle("DDP");
		p10.setContent("서울특별시 중구의 전시장 및 쇼핑몰. 영국의 건축가 자하 하디드가 설계했다. 쇼핑 시설을 겸한 전시장으로 운영하고 있다.");
		p10.setLat(37.5665256);
		p10.setLng(127.0092236);
		
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		list.add(p6);
		list.add(p7);
		list.add(p8);
		list.add(p9);
		list.add(p10);
		
		response.setContentType("application/json; charset=UTF-8");
		new Gson().toJson(list, response.getWriter());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
